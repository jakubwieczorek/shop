package wieczorek.jakub.shopwar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopWarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopWarApplication.class, args);
	}

}
