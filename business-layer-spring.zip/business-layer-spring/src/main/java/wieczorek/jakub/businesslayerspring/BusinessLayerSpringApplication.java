package wieczorek.jakub.businesslayerspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessLayerSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinessLayerSpringApplication.class, args);
	}

}
