package wieczorek.jakub.businesslayerspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessLayerSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
